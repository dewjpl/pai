const Messages = require("./../../models/messages");
const jwt = require("jsonwebtoken");

const fetchMessages = async (req, res) => {
	try {
		const token = req.query.token;
		const decoded = jwt.verify(token, "mailer123");

		if (!decoded) {
			return res.status(200).json({ success: false });
		}

		const user = decoded.email;
		const messages = await Messages.find({ receiver: user });

		return res.status(200).json({ success: true, mails: messages });
	} catch (error) {
		console.error("Error fetching messages:", error);
		return res
			.status(500)
			.json({ success: false, error: "Error fetching messages" });
	}
};

const sendMessages = async (req, res) => {
	try {
		const token = req.query.token;
		const decoded = jwt.verify(token, "mailer123");

		if (!decoded) {
			return res.status(200).json({ success: false });
		}

		const user = decoded.email;
		const messages = await Messages.find({ sender: user });

		return res.status(200).json({ success: true, mails: messages });
	} catch (error) {
		console.error("Error fetching sent messages:", error);
		return res
			.status(500)
			.json({ success: false, error: "Error fetching sent messages" });
	}
};

const deleteMessages = async (req, res) => {
	try {
		const messageId = req.params.id;
		await Messages.findByIdAndDelete(messageId);
		return res
			.status(200)
			.json({ success: true, message: "Message deleted successfully" });
	} catch (error) {
		console.error("Error deleting message:", error);
		return res
			.status(500)
			.json({ success: false, error: "Error deleting message" });
	}
};

const markMessagesAsRead = async (req, res) => {
	try {
		const messageId = req.params.id;
		await Messages.findByIdAndUpdate(messageId, { $set: { read: true } });
		return res
			.status(200)
			.json({ success: true, message: "Message marked as read successfully" });
	} catch (error) {
		console.error("Error marking message as read:", error);
		return res
			.status(500)
			.json({ success: false, error: "Error marking message as read" });
	}
};

module.exports = {
	fetchMessages,
	sendMessages,
	deleteMessages,
	markMessagesAsRead,
};
