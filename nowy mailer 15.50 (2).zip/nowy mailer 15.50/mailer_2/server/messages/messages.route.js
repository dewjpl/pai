const express = require("express");
const router = express.Router();
const messageService = require("./service/messages");

router.get("/api/users/messages", messageService.fetchMessages);
router.post("/api/users/send", messageService.sendMessages);
router.post("/api/users/delete", messageService.deleteMessages);
router.post("/api/users/update", messageService.markMessagesAsRead);

module.exports = router;
