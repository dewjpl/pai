import React, { useState, useEffect } from "react";
import axios from "axios";
import { jwtDecode } from "jwt-decode";
import { useNavigate } from "react-router-dom";
import "./Dashboard.scss";

const SendMessage = () => {
	const [messages, setMessages] = useState([]);
	const [loggedInUser, setLoggedInUser] = useState("");
	const [messageText, setMessageText] = useState("");
	const navigate = useNavigate();

	useEffect(() => {
		const token = sessionStorage.getItem("token");

		if (token) {
			const decoded = jwtDecode(token);
			setLoggedInUser(decoded.email);
		}

		fetchMessages();
	}, []);

	const fetchMessages = async () => {
		const token = sessionStorage.getItem("token");
		try {
			const response = await axios.get("/api/users/messages", {
				params: { token },
			});

			if (response.data.success) {
				setMessages(response.data.mails);
			}
		} catch (error) {
			console.error("Error fetching messages:", error);
		}
	};

	const postMessage = async () => {
		const token = sessionStorage.getItem("token");
		try {
			const response = await axios.post(
				"/api/users/send",
				{ text: messageText },
				{ params: { token } }
			);

			if (response.data.success) {
				setMessages(response.data.mails);
				setMessageText("");
			}
		} catch (error) {
			console.error("Error sending message:", error);
		}
	};

	const deleteMessage = async (messageId) => {
		const token = sessionStorage.getItem("token");
		try {
			const response = await axios.delete(`/api/users/delete/${messageId}`, {
				params: { token },
			});

			if (response.data.success) {
				fetchMessages();
			}
		} catch (error) {
			console.error("Error deleting message:", error);
		}
	};

	const markMessageAsRead = async (messageId) => {
		const token = sessionStorage.getItem("token");
		try {
			const response = await axios.put(
				`/api/users/updat/${messageId}/mark-as-read`,
				null,
				{
					params: { token },
				}
			);

			if (response.data.success) {
				fetchMessages();
			}
		} catch (error) {
			console.error("Error marking message as read:", error);
		}
	};

	const logout = () => {
		sessionStorage.removeItem("token");
		setLoggedInUser("");
		setMessages([]);
		navigate("/login");
	};

	return (
		<div className="container">
			<header>
				<h1>Welcome, {loggedInUser}!</h1>
				<button onClick={logout}>Logout</button>
			</header>

			<div className="messages">
				<h2>Messages</h2>
				{messages.length > 0 ? (
					<ul>
						{messages.map((message) => (
							<li key={message._id}>
								{message.text}{" "}
								<button onClick={() => deleteMessage(message._id)}>
									Delete
								</button>
								<button onClick={() => markMessageAsRead(message._id)}>
									Mark as Read
								</button>
							</li>
						))}
					</ul>
				) : (
					<p>No messages available.</p>
				)}
			</div>

			<div className="sendMessageForm">
				<h2>Send a Message</h2>
				<input
					type="text"
					value={messageText}
					onChange={(e) => setMessageText(e.target.value)}
				/>
				<button onClick={postMessage}>Send</button>
			</div>
		</div>
	);
};

export default SendMessage;
